﻿	export interface IPlayer
	{
		id: string;
		name: string;
		pos: string;
		name_display_first_last: string;
	}
