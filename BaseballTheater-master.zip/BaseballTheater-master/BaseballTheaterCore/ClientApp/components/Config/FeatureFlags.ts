﻿export enum FeatureFlags
{
	None = 0,
	Beta = 1,
	LiveData = 2,
	TeamSchedule = 4
}