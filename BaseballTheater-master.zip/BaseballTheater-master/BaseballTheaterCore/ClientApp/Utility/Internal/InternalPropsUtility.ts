﻿export interface ISinglePropWrapper<T>
{
	data: T;
}