﻿using System;

namespace MlbDataEngine.Contracts
{
	public class GameDay
	{
		public DateTime Date { get; set; }
		
	}
}