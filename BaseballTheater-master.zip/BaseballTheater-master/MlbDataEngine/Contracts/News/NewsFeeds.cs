﻿namespace MlbDataEngine.Contracts.News
{
	public enum NewsFeeds
	{
		mlb,
		mtr,
		fangraphs,
		fivethirtyeight,
		espn,
		reddit
	}
}