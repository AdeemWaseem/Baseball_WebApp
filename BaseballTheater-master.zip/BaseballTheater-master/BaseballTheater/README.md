react-typescript-definitions
============================

React.d.ts, file with ambient type declarations for working with Facebook React.

With typings for React 0.12 (PARTIAL), 0.10.0 and TS 1.1, kinda incomplete, so **pull requests are welcome**.

Based on TodoMVC sample by @fdecampredon, improved by @wizzard0, MIT licensed.

Install via NPM:

    npm install react-typescript-definitions

or via NuGet:

    PM> Install-Package React.TypeScript.DefinitelyTyped 

Use:

    /// <reference path="../node_modules/react-typescript-definitions/react.d.ts" />

