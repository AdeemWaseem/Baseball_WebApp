﻿// ReSharper disable InconsistentNaming

namespace BaseballTheater.Areas.Data.Models.Patreon
{
	public enum Teams
	{
		none,
		ari,
		atl,
		bal,
		bos,
		chc,
		cin,
		chw,
		cle,
		col,
		det,
		hou,
		kc,
		ana,
		la,
		mia,
		mil,
		min,
		nym,
		nyy,
		oak,
		phi,
		pit,
		stl,
		sd,
		sf,
		sea,
		tb,
		tex,
		tor,
		was
	}
}