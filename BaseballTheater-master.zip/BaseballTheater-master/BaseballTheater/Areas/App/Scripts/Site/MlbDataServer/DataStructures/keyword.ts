﻿namespace Theater
{
	export class Keyword
	{
		public type: string;
		public value: string;
	}
}
